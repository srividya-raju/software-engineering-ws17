
public class MetersToMilesConverter extends LengthConverter {
	public MetersToMilesConverter() { }
	
	private static final MetersToMilesConverter INSTANCE = new MetersToMilesConverter();

	  public String convert(double inLength) {
	    return Double.toString(inLength * 0.00062137)+"\n";
	  }
	  
	  public String toString(){
		    return "Meters to Miles Converter"+"\n";
		  }

		  public void print(){
		    System.out.println(toString());
		  }
		  
		  public static UnitConverter create() {
			  return INSTANCE;
			  }
		  
}
