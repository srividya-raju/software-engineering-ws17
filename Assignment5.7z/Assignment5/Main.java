import java.util.LinkedList;
import java.util.Scanner;


class Main {
  public static void main(String[] args)
  {
	  
	  LinkedList<Command> ll = new LinkedList<Command>();
	  
	  Scanner sc = new Scanner(System.in);
	  System.out.println("Please Specify(1/0) if you want inversion:");
	    int inv=sc.nextInt(); 
	  
	  
	  System.out.println("Please two conversions and the value to be converted:(MetersToYards/DollarToEuro/EuroToDollar/MetersToMiles/MilesToMeters/YardsToMeters/CelsiusToFahrenheit/FahrenheitToCelsius)");
	      
	     while (sc.hasNext()) 
	     { 
			String s1 = sc.next();
			String s2 = sc.next();
			Double s3 = sc.nextDouble();
	   	    ll.add(new Command(s1,s2,s3,inv));
	     }
	     

	     
sc.close();
	    //System.out.println();

for(Command c : ll){
	c.setConverter();
	System.out.println(c.Display());
	System.out.println(c.DoAction());
}
	    
	    

      }
}
