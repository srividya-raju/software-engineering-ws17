public class DollarToEuroConverterDecorator extends CurrencyDecorator {
	public DollarToEuroConverterDecorator(UnitConverter c) {
		// TODO Auto-generated constructor stub
		super(c);
	}
	
//	private static final MetersToMilesConverterDecorator INSTANCE = new MetersToMilesConverterDecorator();

	  public String convert(double inDollars) {
		  
	    //return m_base.convert(inLength)+ inLength * 0.00062137;
		  String str= m_base.convert(inDollars)+Double.toString(inDollars*0.85)+"Euros\n";
		  return str;
	  }
	  
	  @Override
	  public String toString(){
		  return m_base.toString()+"Dollar to Euro Converter"+"\n";
		  }
	      @Override
		  public void print(){
		    System.out.println(toString());
		  }

		
		  
		  public static UnitConverter create() {
			  //return INSTANCE;
			  return null;
			  }
		  public String type(){
			  return "Currency";
		  }
}
