
public class FahrenheitToCelsiusConverter extends TemperatureDecorator {
	//public FahrenheitToCelsiusConverter() { }
	
	public FahrenheitToCelsiusConverter(UnitConverter c) {
		// TODO Auto-generated constructor stub
		super(c);
	}
	
	//private static final FahrenheitToCelsiusConverter INSTANCE = new FahrenheitToCelsiusConverter();

	  public String convert(double inTemp) {
	    return m_base.convert(inTemp)+Double.toString((inTemp- 32) /( 9/5) )+" C\n";
	  }
	  
	  public String toString(){
		    return m_base.toString()+"Fahrenheit to Celsius Converter"+"\n";
		  }

		  public void print(){
		    System.out.println(toString());
		  }
		  
		  public static UnitConverter create() {
			  //return INSTANCE;
			  return null;
			  }
		  public String type(){
			  return "Temp";
		  }
}
