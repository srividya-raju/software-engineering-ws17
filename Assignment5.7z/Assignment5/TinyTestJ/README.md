Software Engineering Exercise Class WS17/18
===========================================
