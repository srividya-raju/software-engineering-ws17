public class InversionDecorator extends UnitConverterDecorater {
	//UnitConverter m_base;
	public InversionDecorator(){
		//this.m_base=c;
	}
	public InversionDecorator(UnitConverter c){
		super(c);
		try{
			
			if(c.getClass().getSuperclass().equals(TemperatureDecorator.class))
				throw new Exception();
		}
		catch(Exception e){
			System.out.println("Disabled Inversion for Temperature..");
		}
		
	}

	
	@Override
	public String toString(){
		 String reversed="";
		 String str = m_base.toString();
		 if(!str.equals(" ")){
		 String[] splitstr= str.split("\n");
		 
		 for (int i = splitstr.length - 1; i >= 0; i--) {
		        reversed=reversed+splitstr[i]+"\n";
		    }
		 }
		 return reversed;
	}
	
	@Override
	public String convert(double inValue) {
		// TODO Auto-generated method stub
		String rsv= toString();
		String[] rsv_splitted= rsv.split("\n");
		String Values="";
		for (int i = 0; i <=rsv_splitted.length - 1; i++) {
	       // Values=Values+splitstr[i]+"\n";
			String j=rsv_splitted[i];
			if (j.equals("Meters to Miles Converter"))
			{
				MilesToMetersConverterDecorator m= new MilesToMetersConverterDecorator(new LengthConverter());
				Values=Values+m.convert(inValue)+"\n";
			}
			else if(j.equals("Miles to Meters Converter")){
				MetersToMilesConverterDecorator m= new MetersToMilesConverterDecorator(new LengthConverter());
				Values=Values+m.convert(inValue)+"\n";
			}
			else if(j.equals("Meters to Yards Converter")){
				YardsToMetersD m = new YardsToMetersD(new LengthConverter());
				Values=Values+m.convert(inValue)+"\n";
			}
			else if(j.equals("Yards to Meters Converter")){
				MetersToYardsD m = new MetersToYardsD(new LengthConverter());
				Values=Values+m.convert(inValue)+"\n";
			}
			else if(j.equals("Euro to Dollar Converter")){
				DollarToEuroConverterDecorator m = new DollarToEuroConverterDecorator(new CurrencyConverter());
				Values=Values+m.convert(inValue)+"\n";
			}
			else if(j.equals("Dollar to Euro Converter")){
				EuroToDollarConverter m = new EuroToDollarConverter(new CurrencyConverter());
				Values=Values+m.convert(inValue)+"\n";
			}
			
			
	    }
	 
		
		return Values;
	}
	
	@Override
	public void print() {
		// TODO Auto-generated method stub
		
	}
	
	

}
