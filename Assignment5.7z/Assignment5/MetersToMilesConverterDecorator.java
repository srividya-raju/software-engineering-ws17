public class MetersToMilesConverterDecorator extends LengthDecorator {
	public MetersToMilesConverterDecorator(UnitConverter c) {
		// TODO Auto-generated constructor stub
		super(c);
	}
	
//	private static final MetersToMilesConverterDecorator INSTANCE = new MetersToMilesConverterDecorator();

	  public String convert(double inLength) {
		  
	    //return m_base.convert(inLength)+ inLength * 0.00062137;
		  String str= m_base.convert(inLength)+Double.toString(inLength * 0.00062137)+"mi\n";
		  return str;
	  }
	  
	  @Override
	  public String toString(){
		  return m_base.toString()+"Meters to Miles Converter"+"\n";
		  }
	      @Override
		  public void print(){
		    System.out.println(toString());
		  }
	      
	      public String type(){
			  return "Length";
		  }

			  
//		  public static UnitConverter create() {
//			  return INSTANCE;
//			  }
}
