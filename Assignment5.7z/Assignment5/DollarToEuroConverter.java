
public class DollarToEuroConverter extends UnitConverterDecorater 
{
  public DollarToEuroConverter() { }
  
  //private static final DollarToEuroConverter INSTANCE = new DollarToEuroConverter();

  public DollarToEuroConverter(UnitConverter c) {
	// TODO Auto-generated constructor stub
	  super(c);
	  
}

public String convert(double inDollars) {
    return Double.toString(inDollars*0.85)+"\n";
  }

  public String toString(){
    return "Dollar to Euro Converter"+"\n";
  }

  public void print(){
    System.out.println(toString());
  }
  
  public static UnitConverter create() {
	  //return INSTANCE;
	  return null;
	  }

  public String type(){
	  return "Currency";
  }


  
};
