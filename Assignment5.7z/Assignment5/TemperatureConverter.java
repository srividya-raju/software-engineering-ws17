
public class TemperatureConverter implements UnitConverter {

	@Override
	public String convert(double inValue) {
		// TODO Auto-generated method stub
		return " ";
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return " ";
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub

	}

	@Override
	public String type() {
		// TODO Auto-generated method stub
		return "Temp";
	}

}
