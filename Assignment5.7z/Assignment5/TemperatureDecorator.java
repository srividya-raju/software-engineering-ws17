
public class TemperatureDecorator extends UnitConverterDecorater {
	//public TemperatureDecorator(){}


	public TemperatureDecorator(UnitConverter c) {
		// TODO Auto-generated constructor stub
		super(c);
	}

	
}
