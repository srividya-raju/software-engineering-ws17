

public class UnitConverterDecorater implements UnitConverter {
	UnitConverter m_base;
	public UnitConverterDecorater(){
		//this.m_base=c;
	}
	public UnitConverterDecorater(UnitConverter c){
		this.m_base=c;
	}

	@Override
	public String convert(double inValue) {
		// TODO Auto-generated method stub
		return " ";
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public  String toString(){
		return "Unit"+"\n";
	}
	@Override
	public String type() {
		// TODO Auto-generated method stub
		return "";
	}
}
