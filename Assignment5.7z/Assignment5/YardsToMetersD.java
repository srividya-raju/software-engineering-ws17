
public class YardsToMetersD extends UnitConverterDecorater {
YardsToMetersD() { 
		
	}

	
	YardsToMetersD(UnitConverter c) { 
		super(c);
	}
	
	public String type(){
		  return "Length";
	  }
	
	//private static final MetersToYardsD INSTANCE = new MetersToYardsD();

	  public String convert(double inLength) {
	    return Double.toString(inLength *0.9144)+" m\n";
	  }
	  
	  public String toString(){
		  return m_base.toString()+"Yards to Meters Converter"+"\n";
		  }

		  public void print(){
		    System.out.println(toString());
		  }
		  
		  public static UnitConverter create() {
			  //return INSTANCE;
			  return null;
			  }
}
