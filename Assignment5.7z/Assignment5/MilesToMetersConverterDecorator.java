
public class MilesToMetersConverterDecorator extends UnitConverterDecorater {
	public MilesToMetersConverterDecorator(UnitConverter c) {
		// TODO Auto-generated constructor stub
		super(c);
	}
	
//	private static final MetersToMilesConverterDecorator INSTANCE = new MetersToMilesConverterDecorator();

	  public String convert(double inLength) {
		  
	    //return m_base.convert(inLength)+ inLength * 0.00062137;
		  String str= m_base.convert(inLength)+Double.toString(inLength *1609.344)+"\n";
		  return str;
	  }
	  
	  @Override
	  public String toString(){
		  return m_base.toString()+"Miles To Meters Converter"+"\n";
		  }
	      @Override
		  public void print(){
		    System.out.println(toString());
		  }
		  
//		  public static UnitConverter create() {
//			  return INSTANCE;
//			  }
	      public String type(){
			  return "Length";
		  }
}
