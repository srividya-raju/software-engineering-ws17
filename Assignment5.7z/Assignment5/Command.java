public class Command {
	
	String FirstConversion;
	String SecondConversion;
	Double value;
	int inv;
	UnitConverter mclass;
	UnitConverter mclass2;
	 Command(String s1,String s2,Double d,int i){
		 FirstConversion=s1;
		 SecondConversion=s2;
		 value=d;
	     inv=i;
	 }
	 
	 public void setConverter(){
	 if (FirstConversion.equals("MetersToYards")){
			mclass = new MetersToYardsD(new LengthConverter());
			//return mclass;
		}
		else if (FirstConversion.equals("DollarToEuro")){
			mclass = new DollarToEuroConverterDecorator(new CurrencyConverter());
			}
		else if (FirstConversion.equals("EuroToDollar")){
			mclass = new EuroToDollarConverter(new CurrencyConverter());
			}
		else if (FirstConversion.equals("MetersToMiles")){
			mclass = new MetersToMilesConverterDecorator(new LengthConverter());
			}
		else if (FirstConversion.equals("MilesToMeters")){
			mclass = new MilesToMetersConverterDecorator(new LengthConverter());
			}
		else if (FirstConversion.equals("YardsToMeters")){
			mclass = new YardsToMetersD(new LengthConverter());
			}
		else if (FirstConversion.equals("CelsiusToFahrenheit")){
			mclass = new CelsiusToFahrenheitConverter(new TemperatureConverter());
			}
		else if (FirstConversion.equals("FahrenheitToCelsius")){
			mclass = new FahrenheitToCelsiusConverter(new TemperatureConverter());
			}
	 	else 
			mclass= new UnitConverterDecorater();
	 
	 
	 if (SecondConversion.equals("MetersToYards")){
		 if(inv==1){
			mclass2 = new InversionDecorator(new MetersToYardsD(mclass));
		 }
		 else{
			 mclass2 = (new MetersToYardsD(mclass));}
		}
		else if (SecondConversion.equals("DollarToEuro")){
			if(inv==1){
				mclass2 = new InversionDecorator(new DollarToEuroConverterDecorator(mclass));
			}else{
			mclass2 = new DollarToEuroConverterDecorator(mclass);}
			}
		else if (SecondConversion.equals("EuroToDollar")){
			if(inv==1){
				mclass2 = new InversionDecorator(new EuroToDollarConverter(mclass));
			}else{
			mclass2 = new EuroToDollarConverter(mclass);}
			}
		else if (SecondConversion.equals("MetersToMiles")){
			if(inv==1){
				mclass2 = new InversionDecorator(new MetersToMilesConverterDecorator(mclass));
			}else{
			mclass2 = new MetersToMilesConverterDecorator(mclass);}
			}
		else if (SecondConversion.equals("MilesToMeters")){
			if(inv==1){
				mclass2 = new InversionDecorator(new MilesToMetersConverterDecorator(mclass));
			}else{
			mclass2 = new MilesToMetersConverterDecorator(mclass);}
			}
		else if (SecondConversion.equals("YardsToMeters")){
			if(inv==1){
				mclass2 = new InversionDecorator(new YardsToMetersD(mclass));
			}else{
			mclass2 = new YardsToMetersD(mclass);}
			}
		else if (SecondConversion.equals("CelsiusToFahrenheit")){
			if(inv==1){
				mclass2 = new InversionDecorator(new CelsiusToFahrenheitConverter(mclass));
			}else{
			mclass2 = new CelsiusToFahrenheitConverter(mclass);}
			}
		else if (SecondConversion.equals("FahrenheitToCelsius")){
			if(inv==1){
				mclass2 = new InversionDecorator(new FahrenheitToCelsiusConverter(mclass));
			}else{
			mclass2 = new FahrenheitToCelsiusConverter(mclass);}
			}
		else 
			mclass2= new UnitConverterDecorater(mclass);
	 
	 //return mclass2;
	     
	 }

	public String DoAction() {
		// TODO Auto-generated method stub
		// https://docs.oracle.com/javase/tutorial/reflect/class/classNew.html was referred to fetch the superclass name, etc.
		
if(mclass.type()==mclass2.type()){
	return mclass2.convert(value);
		}else
			return"Type Mismatch";

	}
	
	public String Display() {
		// TODO Auto-generated method stub
		// https://docs.oracle.com/javase/tutorial/reflect/class/classNew.html was referred to fetch the superclass name, etc.
//		if(mclass2.getClass().getSuperclass()!=mclass.getClass().getSuperclass()| mclass2.getClass().getClass().getSuperclass()!=mclass.getClass().getSuperclass()){
//			return "Type Mismatch";
//		
//		}else{
		return mclass2.toString();//}
	}
	
	
	  
	 
	 

}
