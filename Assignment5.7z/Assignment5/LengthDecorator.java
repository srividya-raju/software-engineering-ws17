
public class LengthDecorator extends UnitConverterDecorater {
	

	public LengthDecorator(UnitConverter c) {
		// TODO Auto-generated constructor stub
		super(c);
	}

}
