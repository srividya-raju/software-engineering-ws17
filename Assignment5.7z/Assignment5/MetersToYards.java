
public class MetersToYards extends LengthConverter {
	MetersToYards() { }
	
	private static final MetersToYards INSTANCE = new MetersToYards();

	  public String convert(double inLength) {
	    return Double.toString(inLength /0.9144)+"\n";
	  }
	  
	  public String toString(){
		    return "Meters to Yards Converter"+"\n";
		  }

		  public void print(){
		    System.out.println(toString());
		  }
		  
		  public static UnitConverter create() {
			  return INSTANCE;
			  }
}
