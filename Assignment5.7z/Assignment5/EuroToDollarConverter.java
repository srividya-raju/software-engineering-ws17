public class EuroToDollarConverter extends CurrencyDecorator
{
  //public EuroToDollarConverter() { }
  
  public EuroToDollarConverter(UnitConverter c) {
		// TODO Auto-generated constructor stub
		super(c);
	}
  
  //private static final EuroToDollarConverter INSTANCE = new EuroToDollarConverter();

  public String convert(double inDollars) {
    return m_base.convert(inDollars)+Double.toString(inDollars*1.18)+" Dollars\n";
  }

  public String toString(){
    return m_base.toString()+"Euro to Dollar Converter"+"\n";
  }

  public void print(){
    System.out.println(toString());
  }
  
  public static UnitConverter create() {
	  //return INSTANCE;
	  return null;
	  }
  public String type(){
	  return "Currency";
  }
  
};
