public interface UnitConverter
{

  public  String convert(double inValue);
  public  String toString();
  public  void print();
  public String type();
};

