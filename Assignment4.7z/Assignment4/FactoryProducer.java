
public class FactoryProducer {
	
	public static AbstractFactory getFactory()
	{
		
		//return new ConverterFactory();
		return null;
		
	}

}
