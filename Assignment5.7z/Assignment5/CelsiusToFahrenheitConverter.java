
public class CelsiusToFahrenheitConverter extends TemperatureDecorator {
	//public CelsiusToFahrenheitConverter() { }
	
	public CelsiusToFahrenheitConverter(UnitConverter c) {
		// TODO Auto-generated constructor stub
		super(c);
	}
	
	//private static final CelsiusToFahrenheitConverter INSTANCE = new CelsiusToFahrenheitConverter();

	  public String convert(double inTemp) {
	    return m_base.convert(inTemp)+Double.toString(inTemp * 9/5 + 32)+" F\n";
	  }
	  
	  public String toString(){
		    return m_base.toString()+"Celsius to Fahrenheit Converter"+"\n";
		  }

		  public void print(){
		    System.out.println(toString());
		  }
		  
		  public static UnitConverter create() {
			  //return INSTANCE;
			  return null;
			  }
		  public String type(){
			  return "Temp";
		  }
}
