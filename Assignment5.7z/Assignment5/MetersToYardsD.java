
public class MetersToYardsD extends LengthDecorator {
	
	MetersToYardsD(UnitConverter c) { 
		super(c);
	}
	
	
	
	//private static final MetersToYardsD INSTANCE = new MetersToYardsD();

	  public String convert(double inLength) {
	    return Double.toString(inLength /0.9144)+"yards\n";
	  }
	  
	  public String toString(){
		  return m_base.toString()+"Meters to Yards Converter"+"\n";
		  }

		  public void print(){
		    System.out.println(toString());
		  }
		  public String type(){
			  return "Length";
		  }
		  
		  public static UnitConverter create() {
			  //return INSTANCE;
			  return null;
			  }
}
