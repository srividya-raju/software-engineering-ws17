
public class CurrencyDecorator extends UnitConverterDecorater {
	


	public CurrencyDecorator(UnitConverter c) {
		// TODO Auto-generated constructor stub
		super(c);
	}

	
}
